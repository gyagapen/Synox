﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Synox.Services.ServiceSMS.Entity
{
    enum EnumProjet
    {
        /// <summary>
        /// ProjetId= 1
        /// </summary>
        WindowsMobile = 1,
        /// <summary>
        /// ProjetId= 2
        /// </summary>
        RouteurSms = 2,
        /// <summary>
        /// ProjetId= 3
        /// </summary>
        Solem = 3,
        /// <summary>
        /// ProjetId= 4
        /// </summary>
        BirdyBox = 4,
        /// <summary>
        /// ProjetId= 5
        /// </summary>
        Intervox = 5,
        /// <summary>
        /// ProjetId= 6
        /// </summary>
        Ratcom = 6,
        /// <summary>
        /// ProjetId= 7
        /// </summary>
        GeocityCielVert = 7,
        /// <summary>
        /// ProjetId= 8
        /// </summary>
        GeocityA2C = 8,
        /// <summary>
        /// ProjetId= 100
        /// </summary>
        Autres = 100
    }
}
