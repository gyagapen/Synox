﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Synox.Services.ServiceSMS.Entity
{
    /// <summary>
    /// Sms Envoi
    /// </summary>
    public partial class Sms
    {
        //public int IdMessage { get; set; }
    }
}
